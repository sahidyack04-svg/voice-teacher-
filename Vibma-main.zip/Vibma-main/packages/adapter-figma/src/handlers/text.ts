import { batchHandler, applyFillWithAutoBind, applySizing, isSmallIntrinsic, styleNotFoundHint, suggestTextStyle, warnCrossAxisHug, resolveTextStylesForBatch, type Hint } from "./helpers";

// ─── Figma Handlers ──────────────────────────────────────────────

export function getFontStyle(weight: number): string {
  const map: Record<number, string> = {
    100: "Thin", 200: "Extra Light", 300: "Light", 400: "Regular",
    500: "Medium", 600: "Semi Bold", 700: "Bold", 800: "Extra Bold", 900: "Black",
  };
  return map[weight] || "Regular";
}

// ─── set_text_content ────────────────────────────────────────────

export interface TextContentContext {
  nodeMap: Map<string, TextNode>;
  setCharacters: (node: TextNode, text: string) => Promise<void>;
}

/**
 * Pre-resolve nodes and preload their fonts in one pass.
 */
async function prepSetTextContent(params: any): Promise<TextContentContext> {
  const items = params.items || [params];

  const nodeMap = new Map<string, TextNode>();
  const fontsToLoad = new Map<string, FontName>();
  fontsToLoad.set("Inter::Regular", { family: "Inter", style: "Regular" });

  for (const p of items) {
    const node = await figma.getNodeByIdAsync(p.nodeId);
    if (node?.type === "TEXT") {
      nodeMap.set(p.nodeId, node as TextNode);
      const fn = (node as TextNode).fontName;
      if (fn !== figma.mixed && fn) {
        fontsToLoad.set(`${(fn as FontName).family}::${(fn as FontName).style}`, fn as FontName);
      }
    }
  }

  await Promise.all([...fontsToLoad.values()].map(f => figma.loadFontAsync(f)));
  const { setCharacters } = await import("../utils/figma-helpers");
  return { nodeMap, setCharacters };
}

async function setTextContentSingle(p: any, ctx: TextContentContext): Promise<any> {
  const node = ctx.nodeMap.get(p.nodeId);
  if (!node) {
    const raw = await figma.getNodeByIdAsync(p.nodeId);
    if (!raw) throw new Error(`Node not found: ${p.nodeId}`);
    throw new Error(`Node is not a text node: ${p.nodeId}`);
  }
  await ctx.setCharacters(node, p.text);
  return {};
}

async function setTextContentBatch(params: any) {
  const ctx = await prepSetTextContent(params);
  return batchHandler(params, (item) => setTextContentSingle(item, ctx));
}

// ─── set_text_properties ─────────────────────────────────────────

export interface TextPropsContext {
  nodeMap: Map<string, TextNode>;
  textStyles: any[] | null;
  /** name → resolved BaseStyle (local first, library fallback). Preferred lookup path. */
  textStyleByName: Map<string, any>;
}

/**
 * Pre-resolve nodes, preload current + target fonts, resolve text styles.
 */
export async function prepSetTextProperties(params: any): Promise<TextPropsContext> {
  const items = params.items || [params];

  const nodeMap = new Map<string, TextNode>();
  const fontsToLoad = new Map<string, FontName>();

  for (const p of items) {
    const node = await figma.getNodeByIdAsync(p.nodeId);
    if (node?.type === "TEXT") {
      const tn = node as TextNode;
      nodeMap.set(p.nodeId, tn);
      const fn = tn.fontName;
      if (fn !== figma.mixed && fn) {
        fontsToLoad.set(`${fn.family}::${fn.style}`, fn);
      }
      if (p.fontWeight !== undefined) {
        const style = getFontStyle(p.fontWeight);
        const family = (fn !== figma.mixed && fn) ? fn.family : "Inter";
        fontsToLoad.set(`${family}::${style}`, { family, style });
      }
    }
  }

  // Resolve text styles: local first, library fallback via _textStyleKey.
  const { byName: textStyleByName, fontsToLoad: styleFonts, localStyles } = await resolveTextStylesForBatch(items);
  for (const fn of styleFonts) {
    fontsToLoad.set(`${fn.family}::${fn.style}`, fn);
  }

  await Promise.allSettled(
    [...fontsToLoad.values()].map(f =>
      Promise.race([
        figma.loadFontAsync(f),
        new Promise((_, reject) => setTimeout(() => reject(new Error(`Font load timeout: ${f.family} ${f.style}`)), 3000)),
      ]),
    ),
  );

  const textStyles = items.some((p: any) => p.textStyleName) ? localStyles : null;

  return { nodeMap, textStyles, textStyleByName };
}

export async function setTextPropertiesSingle(p: any, ctx: TextPropsContext) {
  const node = ctx.nodeMap.get(p.nodeId);
  if (!node) {
    const raw = await figma.getNodeByIdAsync(p.nodeId);
    if (!raw) throw new Error(`Node not found: ${p.nodeId}`);
    throw new Error(`Not a text node: ${p.nodeId}`);
  }

  // Text style takes priority. Unresolved name surfaces as error hint.
  const warnings: Hint[] = [];
  let resolvedStyleId = p.textStyleId;
  if (!resolvedStyleId && p.textStyleName) {
    const resolved = ctx.textStyleByName.get(p.textStyleName);
    if (resolved?.id) resolvedStyleId = resolved.id;
  }
  if (resolvedStyleId) {
    const s = await figma.getStyleByIdAsync(resolvedStyleId);
    if (s?.type === "TEXT") await (node as any).setTextStyleIdAsync(s.id);
  } else if (p.textStyleName) {
    warnings.push(styleNotFoundHint("textStyleName", p.textStyleName, (ctx.textStyles || []).map((s: any) => s.name)));
  } else {
    if (p.fontWeight !== undefined) {
      const family = (node.fontName !== figma.mixed && node.fontName) ? node.fontName.family : "Inter";
      node.fontName = { family, style: getFontStyle(p.fontWeight) };
    }
    if (p.fontSize !== undefined) node.fontSize = p.fontSize;
  }

  // Text properties: lineHeight, letterSpacing, textCase, textDecoration
  if (p.lineHeight !== undefined) {
    if (typeof p.lineHeight === "number") node.lineHeight = { value: p.lineHeight, unit: "PIXELS" };
    else if (p.lineHeight.unit === "AUTO") node.lineHeight = { unit: "AUTO" };
    else node.lineHeight = { value: p.lineHeight.value, unit: p.lineHeight.unit };
  }
  if (p.letterSpacing !== undefined) {
    if (typeof p.letterSpacing === "number") node.letterSpacing = { value: p.letterSpacing, unit: "PIXELS" };
    else node.letterSpacing = { value: p.letterSpacing.value, unit: p.letterSpacing.unit };
  }
  if (p.textCase) node.textCase = p.textCase;
  if (p.textDecoration) node.textDecoration = p.textDecoration;

  // Text color: fills is canonical (normalized from fontColor* by batchHandler)

  // lineHeight sanity warnings
  if (p.lineHeight !== undefined && typeof p.lineHeight === "number" && p.lineHeight < 10) {
    warnings.push({ type: "warn", message: `lineHeight ${p.lineHeight}px looks wrong — did you mean {value: ${Math.round(p.lineHeight * 100)}, unit: "PERCENT"}? Bare numbers are pixels.` });
  }
  if (p.lineHeight !== undefined && typeof p.lineHeight === "object" && p.lineHeight.unit === "PERCENT" && p.lineHeight.value < 10) {
    warnings.push({ type: "warn", message: `lineHeight ${p.lineHeight.value}% looks wrong — did you mean ${Math.round(p.lineHeight.value * 100)}%? PERCENT uses whole percentages (e.g. 150 = 1.5×).` });
  }
  if (p.fills !== undefined) {
    await applyFillWithAutoBind(node, { fills: p.fills }, warnings);
  }

  if (p.textAlignHorizontal) node.textAlignHorizontal = p.textAlignHorizontal;
  if (p.textAlignVertical) node.textAlignVertical = p.textAlignVertical;
  if (p.textAutoResize) node.textAutoResize = p.textAutoResize;
  if (p.layoutSizingHorizontal || p.layoutSizingVertical) {
    applySizing(node, node.parent, p, warnings, false);
  }
  // Text with HUG on both axes won't wrap — warn after sizing updates
  if ((p.layoutSizingHorizontal || p.layoutSizingVertical) &&
      node.layoutSizingHorizontal === "HUG" && node.layoutSizingVertical === "HUG") {
    const parentIsAL = node.parent && "layoutMode" in node.parent && (node.parent as any).layoutMode !== "NONE";
    if (parentIsAL && !isSmallIntrinsic(node.parent!)) {
      warnings.push({ type: "warn", message: "Text with HUG on both axes won't wrap. Use layoutSizingHorizontal:\"FILL\" + layoutSizingVertical:\"HUG\" so text fills parent width and wraps, or set textAutoResize:\"HEIGHT\" for fixed-width wrapping." });
    }
  }
  if (p.layoutSizingHorizontal || p.layoutSizingVertical) {
    warnCrossAxisHug(node, node.parent, warnings, "Text");
  }
  if (p.textStyleName && p.textStyleId) {
    warnings.push({ type: "warn", message: "Both textStyleName and textStyleId provided — used textStyleId. Pass only one." });
  }
  if (!resolvedStyleId && !p.textStyleName && !p.textStyleId &&
      (p.fontSize !== undefined || p.fontWeight !== undefined)) {
    const fs = p.fontSize ?? (typeof node.fontSize === "number" ? node.fontSize : 14);
    const fw = p.fontWeight ?? 400;
    warnings.push(await suggestTextStyle(fs, fw));
  }
  const result: any = {};
  if (warnings.length > 0) result.hints = warnings;
  return result;
}

async function setTextPropertiesBatch(params: any) {
  const ctx = await prepSetTextProperties(params);
  return batchHandler(params, (item) => setTextPropertiesSingle(item, ctx));
}

// ─── scan_text_nodes ─────────────────────────────────────────────

async function scanTextSingle(p: any) {
  const node = await figma.getNodeByIdAsync(p.nodeId);
  if (!node) throw new Error(`Node not found: ${p.nodeId}`);

  const limit = p.limit ?? 50;
  const opts = { includePath: p.includePath !== false, includeGeometry: p.includeGeometry !== false };
  const textNodes: any[] = [];
  await collectTextNodes(node, [], [], 0, textNodes, limit, opts);
  const truncated = textNodes.length >= limit;
  return { nodeId: p.nodeId, count: textNodes.length, truncated, textNodes };
}

async function collectTextNodes(node: any, namePath: string[], idPath: string[], depth: number, out: any[], limit: number, opts: { includePath: boolean; includeGeometry: boolean }) {
  if (out.length >= limit) return;
  if (node.visible === false) return;
  const names = [...namePath, node.name || `Unnamed ${node.type}`];
  const ids = [...idPath, node.id];

  if (node.type === "TEXT") {
    let fontFamily = "", fontStyle = "";
    if (node.fontName && typeof node.fontName === "object") {
      if ("family" in node.fontName) fontFamily = node.fontName.family;
      if ("style" in node.fontName) fontStyle = node.fontName.style;
    }
    const entry: any = {
      id: node.id,
      name: node.name || "Text",
      characters: node.characters,
      fontSize: typeof node.fontSize === "number" ? node.fontSize : 0,
      fontFamily,
      fontStyle,
    };
    if (opts.includeGeometry) {
      const bounds = node.absoluteBoundingBox ?? node.absoluteRenderBounds;
      entry.absoluteX = bounds ? bounds.x : null;
      entry.absoluteY = bounds ? bounds.y : null;
      entry.width = bounds ? bounds.width : (node.width ?? 0);
      entry.height = bounds ? bounds.height : (node.height ?? 0);
    }
    if (opts.includePath) {
      entry.path = names.join(" > ");
      entry.pathIds = ids.join(" > ");
      entry.depth = depth;
    }
    out.push(entry);
  }

  if ("children" in node) {
    for (const child of (node as any).children) {
      if (out.length >= limit) break;
      await collectTextNodes(child, names, ids, depth + 1, out, limit, opts);
    }
  }
}

// ─── Legacy handler ──────────────────────────────────────────────

// Legacy handler: set_multiple_text_contents maps to set_text_content
async function setMultipleTextContentsFigma(params: any) {
  // Legacy format: { nodeId: "parent", text: [{ nodeId, text }] }
  const items = params.text || params.items || [];
  return setTextContentBatch({ items, depth: params.depth });
}

export const figmaHandlers: Record<string, (params: any) => Promise<any>> = {
  set_text_content: setTextContentBatch,
  set_text_properties: setTextPropertiesBatch,
  scan_text_nodes: (p) => batchHandler(p, scanTextSingle),
  // Legacy alias
  set_multiple_text_contents: setMultipleTextContentsFigma,
};
